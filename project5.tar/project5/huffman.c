/*
 * huffman.c
 * Lydia Martin
 * June 4, 2023
 * huffman.c impliments a huffman tree to compress a text file 
 */

//libraries
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <assert.h>
#include "pqueue.h"
#include "pack.h"

#define NODE struct node
NODE *nodes[257];

//O(1)
//make node function
static NODE *mknode(int count,NODE *left_node,NODE *right_node){
    
    NODE *np;
    np=malloc(sizeof(NODE));
    assert(np!=NULL);
    np->count=count;
    np->parent=NULL;
    if(left_node!=NULL)
	left_node->parent=np;
    if(right_node!=NULL)
	right_node->parent=np;
    return np;
}

//O(1)
//compares left and right
int compare(NODE *t1, NODE *t2){
    return (t1->count < t2->count) ? -1 : (t1->count > t2->count);
}

//O(n)
//checks depth of tree recursively
static int depth(NODE *node){
    if(node->parent==NULL){
	return 0;
    }   
    return depth(node->parent)+1;
}   

//O(n^2)
//main function for the huffman tree
int main (int argc, char *argv[]){

    if (argc!=3){
	printf("error");
	return 0;
    }
    //step 1
    int counts[257], i;
    for(i=0; i<257;i++){
	counts[i]=0;
	nodes[i]=NULL;
    }
    //step 2
    FILE *fp=fopen(argv[1],"rb");
    int c;
    while((c=getc(fp))!=EOF){
	counts[c]++;	
    }

    //step 3
    PQ *pq;
    pq=createQueue(compare);
    for(i=0;i<256;i++){
	if(counts[i]!=0){
	    addEntry(pq,nodes[i]=mknode(counts[i],NULL,NULL));
	}
    }
    addEntry(pq,nodes[256]=mknode(0,NULL,NULL));
    
    //step 4
    NODE *l;
    NODE *r; 
    while(numEntries(pq)>1){
	r=removeEntry(pq);
	l=removeEntry(pq);
	addEntry(pq,mknode(r->count+l->count,l,r));	
    }
    
    //step 5
    for (i=0;i<257;i++){
	if(nodes[i]!=NULL){
	    if(isprint(i)){
		printf("'%c'",i);
	    }else{
		printf("%03o",i);
	    }
	printf(": %d x %d = %d bits\n",counts[i],depth(nodes[i]),counts[i]*depth(nodes[i]));
	}
    }
    pack(argv[1], argv[2], nodes);
    fclose(fp);
    return 0; 

}
