/*
 * pqueue.c
 * Lydia Martin
 * May 21, 2023
 * pqueue.c is sorts the numbers in a heap tree from lowest to highest 
 */

//libraries
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "pqueue.h"

#define INIT_LENGTH 10
#define p(x) (((x)-1)/2)
#define l(x) ((x) *2+1)
#define r(x) ((x)*2+2)

typedef struct pqueue{
    int count; //number of entries in array
    int length; //length of allocated array
    void **data; //allocated array of enteries
    int (*compare)(); //comparison function
}PQ;

//O(1)
//return a pointer to a new priority queue using compare as its comparison function
PQ *createQueue(int (*compare)()){
    assert(compare!=NULL);
    PQ *pq;
    pq=malloc(sizeof(PQ));
    assert(pq!=NULL);
    pq->length=INIT_LENGTH;
    pq->compare=compare;
    pq->count=0;
    pq->data=malloc(sizeof(void *)*pq->length);
    assert(pq->data!=NULL);

    return pq;
}

//O(1)
//deallocate memory associated with the priority queue pointed to by pq
void destroyQueue(PQ *pq){
    assert(pq!=NULL);
    free(pq->data);
    free(pq);
}

//O(1)
//return the number of entries in the priority queue pointed to by pq
int numEntries(PQ *pq){
    assert(pq!=NULL);
    return pq->count;
}

//O(n)
//add entry to the priority queue pointed to by pq
void addEntry(PQ *pq, void *entry){
    assert(pq!=NULL);
    assert(entry!=NULL);

    if(pq->count==pq->length){
	pq->length=pq->length*2;
	pq->data=realloc(pq->data,sizeof(void*)*pq->length);
    }
    
    int i = pq->count;
    while(i>0&&(*pq->compare)(entry,pq->data[p(i)])<0){
	pq->data[i]=pq->data[p(i)];
	i=p(i);
    }
    pq->data[i]=entry;
    pq->count++;
}

//O(n)
//remove and return the smallest entry from the priority queue pointed to by pq
void *removeEntry(PQ *pq){
    assert(pq!=NULL);
	
    void *min=pq->data[0];
    void *entry=pq->data[pq->count-1];
    int i=0;
    while(l(i)<pq->count){
	int child_idx=l(i);
	if(r(i)<pq->count){
	    if((*pq->compare)(pq->data[child_idx],pq->data[r(i)])>0){
		child_idx =r(i);
	    }
	}
	if((*pq->compare)(pq->data[child_idx],entry)<0){
	    pq->data[i]=pq->data[child_idx];
	    i=child_idx;
	}
	else
	    break;
    }
    pq->data[i]=entry;
    pq->count--;
    return min;
}

