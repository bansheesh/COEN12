/* dataset.h
 * Lydia Martin
 * June 11, 2023
 * dataset.h includes all libraries, defines all constant variables, and declairs all functions
 */ 

//libraries + definitions
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#define ageMin 18
#define ageMax 30
#define maxAges 13
#define maxStudents 3000
#define idMax 2000
#define idMin 1

//hash function
//unsigned inthash(int age, int ID);

//structures
typedef struct node NODE;
 
typedef struct list LIST;
      
typedef struct set SET;

//prototypes
int searchAge(SET *sp, int age);

LIST *createList();

SET *createDataSet();

void destroyDataSet(SET *sp);
      
void insertion(SET *sp, int age, int id);
         
void deletion(SET *sp, int i);

int maxAgeGap(SET *sp);

