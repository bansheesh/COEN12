/* college.c
* Lydia Martin
* June 11, 2023
*  college.c uses the functions found in dataset.c to create and fill a data set with 1000 students with random ages and IDs. It then generates a random age to delete from the set and reports the max age gap found in the set before destroying the set.
*/
         
#include "dataset.h"
			
int main(){
    
    SET *college;
    int NewID,IDGen;
    int PrevID=0;
    int age;    
    int i;

    //create the data set
    college=createDataSet();    

    //initialize set with 1000 random students
    srand((time(NULL)));
    for(i=0;i<1000;i++){
	//generate random age
	age=(rand()%(ageMax-ageMin+1))+ageMin;
	//generate random ID
	IDGen=((rand()%2)+1);
	NewID=PrevID+IDGen;
	PrevID=NewID;
	insertion(college,age,NewID);
    }

    //generage and delete random age
    int gap;
    int newAge;
    newAge=(rand()%(ageMax-ageMin+1))+ageMin;
    int target;
    target=searchAge(college,newAge);
    deletion(college,target);
    
    //report max age
    gap=maxAgeGap(college);
    printf("The max age gap is %d years\n",gap);
    
    //Destroy DataSet
    destroyDataSet(college);
    return 0;
}

						  

