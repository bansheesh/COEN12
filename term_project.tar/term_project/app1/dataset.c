/*  dataset.c
 *  Lydia Martin
 *  June 11, 2023
 *  dataset.c in app1 uses a hash function to insert, delete, and search for specific student ages. This file can also find the max age gap between students.
 */

#include "dataset.h"

typedef struct node{
    int age;
    int ID;
    struct node *next;
    struct node *prev;
}NODE; 

typedef struct list{
    int count;
    NODE *head;
}LIST;

typedef struct set{
    int count;
    int length;
    LIST **lists;
    int min;
    int max;
}SET;

//search ID function
unsigned hash(int k, int m){
    
    return k%m;
}

//searches for the given age inside the data set and returns all IDs under that age
int searchAge(SET *sp, int age){
    
    assert(sp!=NULL);
    printf("Seaching for age:%d\n",age);
    int i = hash(age,sp->length);
    LIST *lp=sp->lists[i];
    if(lp->head->next==NULL){
	printf("Age not found.\n");
	return;
    }
    printf("Found:\n");
    NODE *p;
    p=sp->lists[i]->head->next;
    while(p!=lp->head){
	printf("%d\n",p->ID);
	p=p->next;
    }
    return i;
}

//This function creates the data set and the linked lists to be used for chaining.
SET *createDataSet(){
    int i;
    SET *sp=malloc(sizeof(SET));
    assert(sp!=NULL);
    sp->length=maxAges;
    sp->count=0;
    sp->min=ageMax;
    sp->max=ageMin;

    sp->lists=malloc(sizeof(LIST*)*sp->length);
    assert(sp->lists!=NULL);
       
    for(i=0;i<sp->length;i++){
	LIST *lp=malloc(sizeof(LIST));
	assert(lp!=NULL);
	lp->count=0;
	lp->head=malloc(sizeof(NODE));
	assert(lp->head!=NULL);
	lp->head->next=lp->head;
	lp->head->prev=lp->head;
	sp->lists[i]=lp;
    }
    return sp;
}

//destroys the whole data set by traversing the list and freeing  all pointers
void destroyDataSet(SET *sp){
    assert(sp!=NULL);
    LIST *lp;
    int i;
    for(i=0;i<sp->length;i++){
	lp=sp->lists[i];
	NODE *pDel, *pNext;
	pDel=lp->head;
	do{
	    pNext=pDel->next;
	    free(pDel);
	    pDel=pNext;
	}while(pDel!=lp->head);
	free(lp);
    }
    free(sp->lists);
    free(sp);
}
 
 //inserts the given age and ID using the given set pointer and the hash function. after insertion, updates the max and min ages.
void insertion(SET *sp, int age, int id){
    assert(sp!=NULL);
    int i = hash(age,maxAges);
    LIST *lp=sp->lists[i];
    NODE *new;
    new=malloc(sizeof(NODE));
    assert(new!=NULL);
    new->age=age;
    new->ID=id;

    new->next=lp->head;
    new->prev=lp->head->prev;
    lp->head->prev->next=new;
    lp->head->prev=new;
    lp->count++;

    if(new->age<sp->min){
	sp->min=new->age;
    }
    if(new->age>sp->max){
	sp->max=new->age;
    }

    return;	     
}
 
//deletes a specific ID given by the index by using the set pointer. deletes by freeing the node.
void deletion(SET *sp, int i){
    assert(sp!=NULL);
    LIST *lp=sp->lists[i];
    
    if(lp!=NULL){
	    NODE *p;
	    NODE *temp;
	    p=malloc(sizeof(NODE));
	    p=lp->head->prev;
	    while(lp->count !=0){
		p->prev->next=lp->head;
		lp->head->prev=p->prev;
		temp=p;
		lp->count--;
		p=p->next;
		free(temp);
	    }
	    free(lp);
	    printf("Successfully Deleted!\n");
	}
    return;
}

//finds the difference between the variables (found in the insertion function) max and min age
int maxAgeGap(SET *sp){
    
    int gap;
    gap=sp->max - sp->min;
    
    return gap;

}
