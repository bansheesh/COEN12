/* college.c
* Lydia Martin
* June 11, 2023
* college.c uses the functions found in dataset.c to create and fill a data set with 1000 students with random ages and IDs. It then generates a random age and ID to delete from the set and reports the max age gap found in the set before destroying the set.
*/
         
#include "dataset.h"

int main(){
    
    SET *college;
    int NewID,IDGen;
    int PrevID=0;
    int age;    
    int i;

    //create the data set
    college=createDataSet();    

    //initialize set with 1000 random students
    srand((time(NULL)));
    for(i=0;i<1000;i++){
	//generate random age
	age=(rand()%(ageMax-ageMin+1))+ageMin;
	//generate random ID
	IDGen=((rand()%2)+1);
	NewID=PrevID+IDGen;
	PrevID=NewID;
	//insert data
	insertion(college,age,NewID);
    }
    
    //create and delete random age
    int newAge;
    newAge=(rand()%(ageMax-ageMin+1))+ageMin;
    printf("Age:%d to be searched and deleted.\n",newAge);
    int target;
    target=searchAge(college,newAge);
    deletion(college,target);
    
    //create and delete random ID
    int randID=(rand()%(idMax-idMin+1))+idMin;
    printf("ID: %d to be searched and deleted\n",randID);
    int target1=searchID(college,randID);
    deletion(college,target1);
    
    //max age gap
    int gap;
    gap=maxAgeGap(college);
    printf("The max age gap is %d years\n",gap);
    
    //Destroy DataSet
    destroyDataSet(college);
    return 0;
}

						  

